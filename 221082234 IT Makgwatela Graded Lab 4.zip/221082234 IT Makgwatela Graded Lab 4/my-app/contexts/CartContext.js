import React, { createContext, useState } from 'react';

export const CartContext = createContext();

export const CartProvider = ({ children }) => {
  const [cart, setCart] = useState([]);

  const addToCart = (item) => {
    const existingItem = cart.find(cartItem => cartItem.selectedType.id === item.selectedType.id);
    if (existingItem) {
      setCart(cart.map(cartItem =>
        cartItem.selectedType.id === item.selectedType.id
          ? { ...cartItem, quantity: cartItem.quantity + 1 }
          : cartItem
      ));
    } else {
      setCart([...cart, { ...item, quantity: 1 }]);
    }
  };

  const removeFromCart = (item) => {
    setCart(cart.filter(cartItem => cartItem.selectedType.id !== item.selectedType.id));
  };

  const updateQuantity = (item, amount) => {
    setCart(cart.map(cartItem =>
      cartItem.selectedType.id === item.selectedType.id
        ? { ...cartItem, quantity: Math.max(1, cartItem.quantity + amount) }
        : cartItem
    ));
  };

  return (
    <CartContext.Provider value={{ cart, addToCart, removeFromCart, updateQuantity, setCart }}>
      {children}
    </CartContext.Provider>
  );
};
