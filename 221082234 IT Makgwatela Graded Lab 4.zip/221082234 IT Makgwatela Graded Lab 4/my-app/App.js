import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import MenuScreen from './screens/MenuScreen';
import CartScreen from './screens/CartScreen';
import ProfileScreen from './screens/ProfileScreen';
import { CartProvider } from './contexts/CartContext';
import { ThemeProvider } from './contexts/ThemeContext';
import { FormProvider } from './contexts/FormContext';
import Icon from 'react-native-vector-icons/Ionicons'; // Tab icons

const Tab = createBottomTabNavigator();

export default function App() {
  return (
    <ThemeProvider>
      <CartProvider>
        <FormProvider>
          <NavigationContainer>
            <Tab.Navigator initialRouteName="Menu">
              <Tab.Screen 
                name="Menu" 
                component={MenuScreen} 
                options={{ tabBarIcon: ({ color, size }) => (
                    <Icon name="restaurant" color={color} size={size} />
                  )
                }}
              />
              <Tab.Screen 
                name="Cart" 
                component={CartScreen} 
                options={{ tabBarIcon: ({ color, size }) => (
                    <Icon name="cart" color={color} size={size} />
                  )
                }}
              />
              <Tab.Screen 
                name="Profile" 
                component={ProfileScreen} 
                options={{ tabBarIcon: ({ color, size }) => (
                    <Icon name="person" color={color} size={size} />
                  )
                }}
              />
            </Tab.Navigator>
          </NavigationContainer>
        </FormProvider>
      </CartProvider>
    </ThemeProvider>
  );
}
