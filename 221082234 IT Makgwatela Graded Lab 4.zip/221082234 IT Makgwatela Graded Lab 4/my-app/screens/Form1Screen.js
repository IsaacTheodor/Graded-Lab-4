import React, { useContext, useState } from 'react';
import { View, TextInput, Button, Text, Alert, StyleSheet } from 'react-native';
import { FormContext } from '../contexts/FormContext';

export default function Form1Screen({ navigation }) {
  const { formData, updateFormData } = useContext(FormContext);
  const [localData, setLocalData] = useState({
    name: formData.name || '',
    email: formData.email || '',
    phoneNumber: formData.phoneNumber || '',
  });

  const validateInputs = () => {
    const { name, email, phoneNumber } = localData;
    if (!name || !email || !phoneNumber) {
      Alert.alert("Validation Error", "All fields are required.");
      return false;
    }
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      Alert.alert("Validation Error", "Please enter a valid email address.");
      return false;
    }
    const phoneRegex = /^\d{10}$/;
    if (!phoneRegex.test(phoneNumber)) {
      Alert.alert("Validation Error", "Please enter a valid 10-digit phone number.");
      return false;
    }
    return true;
  };

  const handleNext = () => {
    if (validateInputs()) {
      updateFormData(localData);
      navigation.navigate('Form2');
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.header}>User Details</Text>
      <TextInput
        placeholder="Name"
        value={localData.name}
        onChangeText={(text) => setLocalData({ ...localData, name: text })}
        style={styles.input}
      />
      <TextInput
        placeholder="Email"
        value={localData.email}
        onChangeText={(text) => setLocalData({ ...localData, email: text })}
        keyboardType="email-address"
        style={styles.input}
      />
      <TextInput
        placeholder="Phone Number"
        value={localData.phoneNumber}
        onChangeText={(text) => setLocalData({ ...localData, phoneNumber: text })}
        keyboardType="phone-pad"
        style={styles.input}
      />
      <Button title="Next" onPress={handleNext} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20 },
  header: { fontSize: 24, marginBottom: 20, fontWeight: 'bold' },
  input: { height: 40, borderColor: 'gray', borderWidth: 1, marginBottom: 20, paddingHorizontal: 10 },
});
