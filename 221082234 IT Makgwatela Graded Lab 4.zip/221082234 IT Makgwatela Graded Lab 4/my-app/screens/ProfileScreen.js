import React, { useContext } from 'react';
import { View, Text, StyleSheet, ScrollView } from 'react-native';
import { Picker } from '@react-native-picker/picker';
import { ThemeContext } from '../contexts/ThemeContext';

export default function ProfileScreen({ route }) {
  const { theme, setTheme } = useContext(ThemeContext);

  // Destructure userProfile from route params with a fallback to an empty object
  const { userProfile = {} } = route.params || {};

  // Handle cases where userProfile might be missing
  const userName = userProfile.name || 'No Name Provided';
  const userAddress = userProfile.address || 'No Address Provided';
  const userEmail = userProfile.email || 'No Email Provided';
  const userPhone = userProfile.phoneNumber || 'No Phone Number Provided';

  const handleTextColorChange = (color) => {
    setTheme((prevTheme) => ({
      ...prevTheme,
      textColor: color,
    }));
  };

  const handleBackgroundColorChange = (color) => {
    setTheme((prevTheme) => ({
      ...prevTheme,
      backgroundColor: color,
    }));
  };

  return (
    <ScrollView style={[styles.container, { backgroundColor: theme.backgroundColor }]}>
      <Text style={[styles.header, { color: theme.textColor }]}>Your Profile</Text>

      <View style={[styles.card, { backgroundColor: theme.backgroundColor }]}>
        <Text style={[styles.cardHeader, { color: theme.textColor }]}>Personal Information</Text>
        <Text style={[styles.text, { color: theme.textColor }]}>Name: {userName}</Text>
        <Text style={[styles.text, { color: theme.textColor }]}>Address: {userAddress}</Text>
      </View>

      <View style={[styles.card, { backgroundColor: theme.backgroundColor }]}>
        <Text style={[styles.cardHeader, { color: theme.textColor }]}>Contact Information</Text>
        <Text style={[styles.text, { color: theme.textColor }]}>Email: {userEmail}</Text>
        <Text style={[styles.text, { color: theme.textColor }]}>Phone: {userPhone}</Text>
      </View>

      <View style={[styles.card, { backgroundColor: theme.backgroundColor }]}>
        <Text style={[styles.cardHeader, { color: theme.textColor }]}>Customize App Theme</Text>
        <Text style={[styles.text, { color: theme.textColor }]}>Select Text Color:</Text>
        <Picker
          selectedValue={theme.textColor}
          style={styles.picker}
          onValueChange={handleTextColorChange}
        >
          <Picker.Item label="Black" value="#000000" />
          <Picker.Item label="White" value="#FFFFFF" />
          <Picker.Item label="Red" value="#FF0000" />
          <Picker.Item label="Blue" value="#0000FF" />
          <Picker.Item label="Green" value="#008000" />
        </Picker>

        <Text style={[styles.text, { color: theme.textColor }]}>Select Background Color:</Text>
        <Picker
          selectedValue={theme.backgroundColor}
          style={styles.picker}
          onValueChange={handleBackgroundColorChange}
        >
          <Picker.Item label="White" value="#FFFFFF" />
          <Picker.Item label="Black" value="#000000" />
          <Picker.Item label="Gray" value="#808080" />
          <Picker.Item label="Yellow" value="#FFFF00" />
          <Picker.Item label="Light Blue" value="#ADD8E6" />
        </Picker>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
  },
  header: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  card: {
    padding: 20,
    marginBottom: 20,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#ccc',
  },
  cardHeader: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  text: {
    fontSize: 16,
    marginBottom: 10,
  },
  picker: {
    height: 50,
    width: '100%',
  },
});
