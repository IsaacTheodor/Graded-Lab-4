import React, { useState } from 'react';
import { View, TextInput, Button, Text, Alert, StyleSheet } from 'react-native';

export default function Form2Screen({ navigation, route }) {
  const [addressData, setAddressData] = useState({ address: '', city: '', state: '', zipCode: '' });
  const { userData } = route.params;

  const validateInputs = () => {
    const { address, city, state, zipCode } = addressData;

    // Check if any field is empty
    if (!address || !city || !state || !zipCode) {
      Alert.alert("Validation Error", "All fields are required.");
      return false;
    }

    // Validate zip code (assuming a 5-digit format for demonstration)
    const zipCodeRegex = /^\d{5}$/;
    if (!zipCodeRegex.test(zipCode)) {
      Alert.alert("Validation Error", "Please enter a valid 5-digit zip code.");
      return false;
    }

    return true;
  };

  const handleNext = () => {
    if (validateInputs()) {
      navigation.navigate('Form3', { userData, addressData });
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.header}>Address Details</Text>
      
      <TextInput
        placeholder="Address"
        value={addressData.address}
        onChangeText={(text) => setAddressData({ ...addressData, address: text })}
        style={styles.input}
      />

      <TextInput
        placeholder="City"
        value={addressData.city}
        onChangeText={(text) => setAddressData({ ...addressData, city: text })}
        style={styles.input}
      />

      <TextInput
        placeholder="State"
        value={addressData.state}
        onChangeText={(text) => setAddressData({ ...addressData, state: text })}
        style={styles.input}
      />

      <TextInput
        placeholder="Zip Code"
        value={addressData.zipCode}
        onChangeText={(text) => setAddressData({ ...addressData, zipCode: text })}
        keyboardType="numeric"
        style={styles.input}
      />

      <Button title="Next" onPress={handleNext} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
  },
  header: {
    fontSize: 24,
    marginBottom: 20,
    fontWeight: 'bold',
  },
  input: {
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    marginBottom: 20,
    paddingHorizontal: 10,
  },
});
