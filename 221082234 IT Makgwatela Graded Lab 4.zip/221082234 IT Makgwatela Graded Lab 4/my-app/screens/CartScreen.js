import React, { useContext } from 'react';
import { View, Text, FlatList, Button, Image, StyleSheet, Alert } from 'react-native';
import { CartContext } from '../contexts/CartContext';

export default function CartScreen({ navigation }) {
  const { cart, updateQuantity, removeFromCart, setCart } = useContext(CartContext);

  const getTotal = () => {
    return cart.reduce((sum, item) => sum + item.selectedType.price * item.quantity, 0).toFixed(2);
  };

  const handleCheckout = () => {
    Alert.alert(
      "Checkout",
      "Are you sure you want to checkout?",
      [
        { text: "Cancel", style: "cancel" },
        {
          text: "OK", onPress: () => {
            setCart([]);
            navigation.navigate('Menu');
          }
        }
      ]
    );
  };

  const renderItem = ({ item }) => (
    <View style={styles.itemContainer}>
      <Image source={item.selectedType.image} style={styles.image} />
      <View style={styles.detailsContainer}>
        <Text style={styles.name}>{item.selectedType.name}</Text>
        <Text>Price: R{item.selectedType.price.toFixed(2)}</Text>
        <Text>Quantity: {item.quantity}</Text>
        <View style={styles.buttonGroup}>
          <Button title="+" onPress={() => updateQuantity(item, 1)} />
          <Button title="-" onPress={() => updateQuantity(item, -1)} />
          <Button title="Remove" onPress={() => removeFromCart(item)} />
        </View>
      </View>
    </View>
  );

  return (
    <View style={styles.container}>
      <Text style={styles.header}>Your Cart</Text>
      <FlatList
        data={cart}
        renderItem={renderItem}
        keyExtractor={(item) => item.selectedType.id}
      />
      <Text style={styles.total}>Total: R{getTotal()}</Text>
      <Button title="Proceed to Checkout" onPress={handleCheckout} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20 },
  header: { fontSize: 24, marginBottom: 10 },
  itemContainer: { flexDirection: 'row', padding: 10, borderBottomWidth: 1, borderBottomColor: '#ccc' },
  detailsContainer: { flex: 1, marginLeft: 10 },
  image: { width: 80, height: 80 },
  name: { fontSize: 18, fontWeight: 'bold' },
  buttonGroup: { flexDirection: 'row', marginTop: 10, justifyContent: 'space-between' },
  total: { fontSize: 20, marginTop: 20, textAlign: 'right' },
});
