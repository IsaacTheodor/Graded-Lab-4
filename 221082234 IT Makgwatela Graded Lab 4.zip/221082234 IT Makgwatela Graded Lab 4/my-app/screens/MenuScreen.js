// MenuScreen.js
import React, { useContext } from 'react';
import { View, Text, FlatList, Image, Button, StyleSheet, ScrollView } from 'react-native';
import { CartContext } from '../contexts/CartContext';

// Import local images
import pizzaImage1 from '../assets/Neapolitan_Pizza.jpeg';
import pizzaImage2 from '../assets/Pepperoni_Pizza.jpeg';
import pizzaImage3 from '../assets/Supreme_Pizza.jpeg';
import burgerImage1 from '../assets/Beef_Burger.jpeg';
import burgerImage2 from '../assets/Hamburger.jpeg';
import burgerImage3 from '../assets/Chicken_Burger.jpeg';
import pastaImage1 from '../assets/Italian_Pasta.jpeg';
import pastaImage2 from '../assets/Penne_Pasta.jpeg';
import pastaImage3 from '../assets/Bucatini_Pasta.jpeg';
import sushiImage1 from '../assets/Makizushi_Sushi.jpeg';
import sushiImage2 from '../assets/Temari_Sushi.jpeg';
import sushiImage3 from '../assets/Inari_Sushi.jpeg';
import saladImage1 from '../assets/Greek_Salad.jpeg';
import saladImage2 from '../assets/Caesar_Salad.jpeg';
import saladImage3 from '../assets/Chicken_Salad.jpeg';
import iceCreamImage1 from '../assets/Vanilla_Icecream.jpeg';
import iceCreamImage2 from '../assets/Chocolate_Icecream.jpeg';
import iceCreamImage3 from '../assets/Strawberry_Icecream.jpeg';
import chakalakaImage1 from '../assets/Regular_Chakalaka.jpeg';
import chakalakaImage2 from '../assets/Spicy_Chakalaka.jpeg';
import chakalakaImage3 from '../assets/Extra_Spicy_Chakalaka.jpeg';
import boereworsImage1 from '../assets/Boerewors_with_Mielie_Pap.jpeg';
import boereworsImage2 from '../assets/Boerewors_Extra_Spicy.jpeg';
import boereworsImage3 from '../assets/Boerewors_and_Chakalaka_Pita.jpeg';

const foodItems = [
  {
    id: '1',
    name: 'Pizza',
    types: [
      { id: '1a', name: 'Neapolitan Pizza', price: 120.99, image: pizzaImage1 },
      { id: '1b', name: 'Pepperoni Pizza', price: 128.99, image: pizzaImage2 },
      { id: '1c', name: 'Supreme Pizza', price: 134.99, image: pizzaImage3 },
    ],
  },
  {
    id: '2',
    name: 'Burger',
    types: [
      { id: '2a', name: 'Beef Burger', price: 79.99, image: burgerImage1 },
      { id: '2b', name: 'HamBurger', price: 60.99, image: burgerImage2 },
      { id: '2c', name: 'Chicken Burger', price: 76.99, image: burgerImage3 },
    ],
  },
  {
    id: '3',
    name: 'Pasta',
    types: [
      { id: '3a', name: 'Italian Pasta', price: 79.99, image: pastaImage1 },
      { id: '3b', name: 'Penne Pasta', price: 65.99, image: pastaImage2 },
      { id: '3c', name: 'Bucatini Pasta', price: 89.99, image: pastaImage3 },
    ],
  },
  {
    id: '4',
    name: 'Sushi',
    types: [
      { id: '4a', name: 'Makizushi Sushi', price: 59.99, image: sushiImage1 },
      { id: '4b', name: 'Temari Sushi', price: 89.99, image: sushiImage2 },
      { id: '4c', name: 'Inari Sushi', price: 84.99, image: sushiImage3 },
    ],
  },
  {
    id: '5',
    name: 'Salad',
    types: [
      { id: '5a', name: 'Caesar Salad', price: 50.99, image: saladImage1 },
      { id: '5b', name: 'Greek Salad', price: 67.99, image: saladImage2 },
      { id: '5c', name: 'Chicken Salad', price: 76.99, image: saladImage3 },
    ],
  },
  {
    id: '6',
    name: 'Ice Cream',
    types: [
      { id: '6a', name: 'Vanilla IceCream', price: 20.99, image: iceCreamImage1 },
      { id: '6b', name: 'Chocolate IceCream', price: 41.99, image: iceCreamImage2 },
      { id: '6c', name: 'Strawberry IceCream', price: 26.50, image: iceCreamImage3 },
    ],
  },
  {
    id: '7',
    name: 'Chakalaka and Pap',
    types: [
      { id: '7a', name: 'Regular', price: 55.99, image: chakalakaImage1 },
      { id: '7b', name: 'Spicy', price: 65.49, image: chakalakaImage2 },
      { id: '7c', name: 'Extra Spicy', price: 70.99, image: chakalakaImage3 },
    ],
  },
  {
    id: '8',
    name: 'Boerewors and Pap',
    types: [
      { id: '8a', name: 'Boerewors with Mielie Pap', price: 80.99, image: boereworsImage1 },
      { id: '8b', name: 'Boerewors Extra Spicy', price: 85.49, image: boereworsImage2 },
      { id: '8c', name: 'Boerewors and Chakalaka Pita', price: 90.99, image: boereworsImage3 },
    ],
  },
];

export default function MenuScreen({ navigation }) {
  const { addToCart } = useContext(CartContext);

  const handleGoToCart = () => {
    navigation.navigate('Cart');
  };


  const renderItem = ({ item }) => (
    <View style={styles.itemContainer}>
      <Text style={styles.name}>{item.name}</Text>
      <ScrollView horizontal>
        {item.types.map((type) => (
          <View key={type.id} style={styles.typeContainer}>
            <Image source={type.image} style={styles.image} />
            <Text>{type.name}</Text>
            <Text>R{type.price.toFixed(2)}</Text>
            <Button title="Add to Cart" onPress={() => addToCart({ ...item, selectedType: type })} />
          </View>
        ))}
      </ScrollView>
    </View>
  );

  return (
    <View style={styles.container}>
      <FlatList
        data={foodItems}
        renderItem={renderItem}
        keyExtractor={(item) => item.id}
      />
      <Button title="Go to Cart" onPress={handleGoToCart} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20 },
  itemContainer: { flex: 1, margin: 10, padding: 10, borderWidth: 1, borderColor: '#ccc', borderRadius: 8 },
  typeContainer: { alignItems: 'center', marginRight: 20 },
  image: { width: 100, height: 100, marginBottom: 10 },
  name: { fontSize: 18, fontWeight: 'bold', marginBottom: 10 },
});
