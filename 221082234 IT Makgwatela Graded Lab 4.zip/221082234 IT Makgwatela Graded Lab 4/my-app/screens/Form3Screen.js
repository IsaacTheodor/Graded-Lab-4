import React, { useState } from 'react';
import { View, TextInput, Button, Text, Alert, StyleSheet } from 'react-native';

export default function Form3Screen({ route }) {
  const [paymentData, setPaymentData] = useState({
    cardNumber: '',
    expiryMonth: '',
    expiryYear: '',
    cvv: '',
  });

  const { userData, addressData } = route.params;

  // Validate payment details before submitting
  const validatePaymentDetails = () => {
    const { cardNumber, expiryMonth, expiryYear, cvv } = paymentData;

    // Validate card number (16 digits)
    if (cardNumber.length !== 16 || !/^\d{16}$/.test(cardNumber)) {
      Alert.alert("Validation Error", "Please enter a valid 16-digit card number.");
      return false;
    }

    // Validate expiry month (1-12)
    const month = parseInt(expiryMonth, 10);
    if (isNaN(month) || month < 1 || month > 12) {
      Alert.alert("Validation Error", "Please enter a valid expiration month (01-12).");
      return false;
    }

    // Validate expiry year (4 digits, greater than current year)
    const currentYear = new Date().getFullYear();
    const year = parseInt(expiryYear, 10);
    if (isNaN(year) || year < currentYear || expiryYear.length !== 4) {
      Alert.alert("Validation Error", "Please enter a valid expiration year (YYYY).");
      return false;
    }

    // Validate CVV (3 digits)
    if (cvv.length !== 3 || !/^\d{3}$/.test(cvv)) {
      Alert.alert("Validation Error", "Please enter a valid 3-digit CVV.");
      return false;
    }

    return true;
  };

  const handleSubmit = () => {
    if (validatePaymentDetails()) {
      const completeData = {
        userData,
        addressData,
        paymentData,
      };
      console.log('Final Data:', completeData);
      // Proceed with form submission or API request
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.header}>Payment Details</Text>

      <TextInput
        placeholder="Card Number"
        value={paymentData.cardNumber}
        onChangeText={(text) => setPaymentData({ ...paymentData, cardNumber: text })}
        keyboardType="numeric"
        maxLength={16}
        style={styles.input}
      />

      <View style={styles.expiryContainer}>
        <TextInput
          placeholder="MM"
          value={paymentData.expiryMonth}
          onChangeText={(text) => setPaymentData({ ...paymentData, expiryMonth: text })}
          keyboardType="numeric"
          maxLength={2}
          style={[styles.input, styles.expiryInput]}
        />
        <TextInput
          placeholder="YYYY"
          value={paymentData.expiryYear}
          onChangeText={(text) => setPaymentData({ ...paymentData, expiryYear: text })}
          keyboardType="numeric"
          maxLength={4}
          style={[styles.input, styles.expiryInput]}
        />
      </View>

      <TextInput
        placeholder="CVV"
        value={paymentData.cvv}
        onChangeText={(text) => setPaymentData({ ...paymentData, cvv: text })}
        keyboardType="numeric"
        maxLength={3}
        style={styles.input}
      />

      <Button title="Submit" onPress={handleSubmit} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
  },
  header: {
    fontSize: 24,
    marginBottom: 20,
    fontWeight: 'bold',
  },
  input: {
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    marginBottom: 20,
    paddingHorizontal: 10,
  },
  expiryContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  expiryInput: {
    flex: 1,
    marginRight: 10,
  },
});
